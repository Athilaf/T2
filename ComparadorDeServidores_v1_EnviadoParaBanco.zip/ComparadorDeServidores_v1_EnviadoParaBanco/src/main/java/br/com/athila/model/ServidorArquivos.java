package br.com.athila.model;

import java.util.ArrayList;
import java.util.List;

public class ServidorArquivos {

	public String nomeServidor;
	public List<Arquivo> listaArquivos = new ArrayList<Arquivo>(0);
	
	public ServidorArquivos(String nomeServidor, List<Arquivo> listaArquivos){
		this.nomeServidor = nomeServidor;
		this.listaArquivos = listaArquivos;
	}
	
	public Boolean equals(List<Arquivo> listaB){
		Boolean retorno = true;
		
		if(listaArquivos.size() == listaB.size()){ 
			for (Arquivo a : listaArquivos) {
				
				retorno = false;
				
				for (Arquivo b : listaB) {
					if(a.equals(b)){
						retorno = true;
						break;
					}
				}
				
				if(!retorno){
					break;
				}
		    }
		}else{
			return false;
		}
		
		return retorno;
	}
	
	public Boolean contem(Arquivo arq){
		Boolean retorno = false;
		
		for (Arquivo a : listaArquivos) {
			
			if(a.nome.equals(arq.nome)){
				retorno = true;
				break;
			}
	    }
		
		return retorno;
	}
	
	public Boolean contem(List<Arquivo> arqs){
		Boolean retorno = false;
		
		for (Arquivo a : arqs) {
			
			if(contem(a)){
				retorno = true;
				break;
			}
	    }
		
		return retorno;
	}
	
	public Boolean contemIgual(Arquivo arq){
		Boolean retorno = false;
		
		for (Arquivo a : listaArquivos) {
			
			if(a.equals(arq)){
				retorno = true;
				break;
			}
	    }
		
		return retorno;
	}
	
	public Boolean contemIgual(List<Arquivo> arqs){
		Boolean retorno = false;
		
		for (Arquivo a : arqs) {
			
			if(contemIgual(a)){
				retorno = true;
				break;
			}
	    }
		
		return retorno;
	}
	
	public Arquivo getArquivo(String nome){
	
		for (Arquivo a : listaArquivos) {
			
			if(a.nome.toLowerCase().equals(nome.toLowerCase())){
				return a;
			}
	    }
		
		return null;
	}
	
}
