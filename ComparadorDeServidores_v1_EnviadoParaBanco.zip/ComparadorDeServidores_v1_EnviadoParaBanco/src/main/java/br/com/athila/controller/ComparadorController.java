package br.com.athila.controller;

import java.io.IOException;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.databind.ObjectMapper;

import br.com.athila.model.ResultadoComparacaoArquivos;
import br.com.athila.model.ResultadoComparacaoJson;
import br.com.athila.util.AthilaJson;
import br.com.athila.util.AthilaRestClient;
import br.com.athila.util.AthilaSSH;

@Controller
public class ComparadorController {
	
	@RequestMapping(value="/")
	public String index(){
		return "index";
	}
	
	@RequestMapping(value="/receberServidoresComparacaoArquivos")
    @ResponseBody
	public String receberServidoresComparacaoArquivos(String[] dados){
		
		String saida = "";
		
		if(dados!=null && dados.length > 0){

			String[] nomes = new String[dados.length];
			String[] caminhos = new String[dados.length];
			
			for(int i = 0 ; dados.length > i ; i++){
			
				String[] sDividido = dados[i].split(";");
				
				if(sDividido.length > 1){
					nomes[i] = sDividido[0];
					caminhos[i] = sDividido[1];
				}
				
			}
			
			VersoesArquivos versoesDeArquivos = new VersoesArquivos();

			for(int i = 0 ; nomes.length > i ; i++){
				if(nomes[i] != null && !nomes[i].isEmpty() && caminhos[i] != null && !caminhos[i].isEmpty()){
					AthilaSSH ssh = new AthilaSSH(nomes[i], 22, "linuxdesenv", "linuxdesenv");
					versoesDeArquivos.addForStrings(nomes[i] + ":" + caminhos[i], ssh.getArquivos(caminhos[i]));
					ssh.Disconect();
				}
			}
			
			List<ResultadoComparacaoArquivos> listaResultadoComparacao = versoesDeArquivos.Comparar();
			saida += AthilaJson.ConvertObjectToJsonString(listaResultadoComparacao);
			 
			return saida;
			
		}else{
			saida = "[\"Nenhum servidor recebido\"]";
		}
		
		return  saida;
	}
	
	@RequestMapping(value="/receberServidoresComparacaoJsons")
    @ResponseBody
	public String receberServidoresComparacaoJsons(String[] dados){
		
		String saida = "";
		
		if(dados!=null && dados.length > 0){

			String[] nomes = new String[dados.length];
			String[] caminhos = new String[dados.length];
			
			for(int i = 0 ; dados.length > i ; i++){
			
				String[] sDividido = dados[i].split(";");
				
				if(sDividido.length > 1){
					nomes[i] = sDividido[0];
					caminhos[i] = sDividido[1];
				}
				
			}
			
			VersoesJsons versoesJsons = new VersoesJsons();
			AthilaRestClient restClient = new AthilaRestClient();

			for(int i = 0 ; nomes.length > i ; i++){
				if(nomes[i] != null && !nomes[i].isEmpty() && caminhos[i] != null && !caminhos[i].isEmpty()){
					versoesJsons.add(nomes[i] + ":" + caminhos[i], AthilaJson.listaItens(restClient.get(caminhos[i])));
				}
			}
			
			 List<ResultadoComparacaoJson> listaResultadoComparacao = versoesJsons.Comparar();
			 saida += AthilaJson.ConvertObjectToJsonString(listaResultadoComparacao);
			 
			 return saida;
			
		}else{
			saida = "[\"Nenhum servidor recebido\"]";
		}
		
		return  saida;
	}
	
	@RequestMapping(value="/receberTeste")
    @ResponseBody
	public String receberTeste(String[] dados){
		
		System.out.println(dados);
		
		for(String s: dados){
			System.out.println(s);
		}
		
		String saida = "";
		ObjectMapper mapper = new ObjectMapper();

		try {
			String jsonInString = mapper.writeValueAsString(dados);
			
			saida = jsonInString;
		
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return  saida;
	}
	
	@RequestMapping(value="/ArquivosTesteDireto")
    @ResponseBody
    public String ArquivosTesteDireto() {

		 String caminho1 = "\"Área de Trabalho/AcessoDeFora/Versao1\"";
		 String caminho2 = "\"Área de Trabalho/AcessoDeFora/Versao2\"";
		 String caminho3 = "\"Área de Trabalho/AcessoDeFora/Versao3\"";
		 String saida = "";
		 
		 AthilaSSH ssh = new AthilaSSH("192.168.0.186", 22, "linuxdesenv", "linuxdesenv");
		 
		 VersoesArquivos versoesDeArquivos = new VersoesArquivos();
		 
		 versoesDeArquivos.addForStrings("servidorA", ssh.getArquivos(caminho1));
		 versoesDeArquivos.addForStrings("servidorB", ssh.getArquivos(caminho2));
		 versoesDeArquivos.addForStrings("servidorC", ssh.getArquivos(caminho3));
		 versoesDeArquivos.addForStrings("servidorD", ssh.getArquivos(caminho2));
		 versoesDeArquivos.addForStrings("servidorE", ssh.getArquivos(caminho1));
		 
		 ssh.Disconect();

		 List<ResultadoComparacaoArquivos> listaResultadoComparacao = versoesDeArquivos.Comparar();
		 saida += AthilaJson.ConvertObjectToJsonString(listaResultadoComparacao);
		 
		 return saida;
	 }
	
	@RequestMapping(value="/JsonsTesteDireto")
    @ResponseBody
    public String JsonsTesteDireto() {

		 String caminho1 = "http://localhost:8080/ComparadorDeServidores/JsonExemplo1";
		 String caminho2 = "http://localhost:8080/ComparadorDeServidores/JsonExemplo2";
		 //String caminho3 = "http://localhost:8080/ComparadorDeServidores/JsonExemplo3";
		 String saida = "";
		 
		 AthilaRestClient restClient = new AthilaRestClient();
		 
		 VersoesJsons versoesJsons = new VersoesJsons();
		 
		 versoesJsons.add(caminho1, AthilaJson.listaItens(restClient.get(caminho1)));
		 versoesJsons.add(caminho2, AthilaJson.listaItens(restClient.get(caminho2)));

		 List<ResultadoComparacaoJson> listaResultadoComparacao = versoesJsons.Comparar();
		 saida += AthilaJson.ConvertObjectToJsonString(listaResultadoComparacao);
		 
		 return saida;
	}
	
	@RequestMapping(value="/JsonExemplo1")
    @ResponseBody
    public String JsonExemplo1() {
		return AthilaJson.JsonExemplo1();
	}
	
	@RequestMapping(value="/JsonExemplo2")
    @ResponseBody
    public String JsonExemplo2() {
		return AthilaJson.JsonExemplo2();
	}
	
	@RequestMapping(value="/C4")
    @ResponseBody
    public String C4() {
		
		String saida = "";
		String s = "";
		
		s = "";
		try {
			s += AthilaJson.Ordenacao.sort(AthilaJson.JsonExemplo1());
		} catch (Exception e) {
			saida += "ERRO";
		}
				
		saida += AthilaJson.listaItensString(AthilaJson.ConvertToJsonNode(s));
		saida += "\n\n";

		s = "";
		try {
			s += AthilaJson.Ordenacao.sort(AthilaJson.JsonExemplo2());
		} catch (Exception e) {
			saida += "ERRO";
		}
				
		saida += AthilaJson.listaItensString(AthilaJson.ConvertToJsonNode(s));
		saida += "\n\n";

		
		return saida;
	}
	
//	@RequestMapping(value="/C5")
//    @ResponseBody
//    public String C5() {
//		
//		String saida = "";
//		
//		try {
//		
//			saida+= AthilaJson.ConvertObjectToJsonString(AthilaJson.DiffComparacao(AthilaJson.JsonExemplo1_Obj(), AthilaJson.JsonExemplo2_Obj()));
//
//		} catch (Exception e) {
//			saida += "ERRO";
//		}
//		
//		return saida;
//	}
	
	@RequestMapping(value="/TesteRestDireto")
    @ResponseBody
    public String TesteRestDireto() {
		
		AthilaRestClient r = new AthilaRestClient();
		
		//return r.get("http://gturnquist-quoters.cfapps.io/api/random");
		
		
		return AthilaJson.listaItensString(AthilaJson.ConvertToJsonNode(r.get("http://gturnquist-quoters.cfapps.io/api/")));
		
	}
	
	
}
