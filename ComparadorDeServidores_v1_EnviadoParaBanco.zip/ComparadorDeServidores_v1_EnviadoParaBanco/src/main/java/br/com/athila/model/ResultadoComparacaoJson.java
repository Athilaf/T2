package br.com.athila.model;

import java.util.ArrayList;
import java.util.List;

public class ResultadoComparacaoJson{

	public Integer numeroVersaoA;
	public Integer numeroVersaoB;
	public List<String> servidoresA = new ArrayList<String>(0);
	public List<String> servidoresB = new ArrayList<String>(0);
	
	public List<ComparacaoJson> iguais = new ArrayList<ComparacaoJson>(0);
	public List<ComparacaoJson> diferentes = new ArrayList<ComparacaoJson>(0);
	public List<ComparacaoJson> naoExistem = new ArrayList<ComparacaoJson>(0);
	
	public Integer getNumeroVersaoA() {
		return numeroVersaoA;
	}

	public void setNumeroVersaoA(Integer numeroVersaoA) {
		this.numeroVersaoA = numeroVersaoA;
	}

	public Integer getNumeroVersaoB() {
		return numeroVersaoB;
	}

	public void setNumeroVersaoB(Integer numeroVersaoB) {
		this.numeroVersaoB = numeroVersaoB;
	}

	public List<String> getServidoresA() {
		return servidoresA;
	}

	public void setServidoresA(List<String> servidoresA) {
		this.servidoresA = servidoresA;
	}

	public List<String> getServidoresB() {
		return servidoresB;
	}

	public void setServidoresB(List<String> servidoresB) {
		this.servidoresB = servidoresB;
	}

	public List<ComparacaoJson> getIguais() {
		return iguais;
	}

	public void setIguais(List<ComparacaoJson> iguais) {
		this.iguais = iguais;
	}

	public List<ComparacaoJson> getDiferentes() {
		return diferentes;
	}

	public void setDiferentes(List<ComparacaoJson> diferentes) {
		this.diferentes = diferentes;
	}

	public List<ComparacaoJson> getNaoExistem() {
		return naoExistem;
	}

	public void setNaoExistem(List<ComparacaoJson> naoExistem) {
		this.naoExistem = naoExistem;
	}
	
	public void addIguais(ChaveValor a, ChaveValor b){
		Boolean jaExiste = false;
		for(ComparacaoJson arqs : iguais){
			if(arqs.chaveValorA.equals(a) && arqs.chaveValorB.equals(b)){
				jaExiste = true;
				break;
			}
		}
		
		if(!jaExiste){
			iguais.add(new ComparacaoJson( a , b ));
		}
	}
	
	public void addDiferentes(ChaveValor a, ChaveValor b){
		Boolean jaExiste = false;
		for(ComparacaoJson arqs : diferentes){
			if(arqs.chaveValorA.equals(a) && arqs.chaveValorB.equals(b)){
				jaExiste = true;
				break;
			}
		}
		
		if(!jaExiste){
			diferentes.add(new ComparacaoJson( a , b ));
		}
	}
	
	public void addNaoExistem(ChaveValor a, ChaveValor b){
		Boolean jaExiste = false;
		for(ComparacaoJson arqs : naoExistem){
			
			if(
				(a == null && arqs.chaveValorA == null && arqs.chaveValorB != null && b != null && arqs.chaveValorB.equals(b)) || 
				(b == null && arqs.chaveValorB == null && arqs.chaveValorA != null && a != null && arqs.chaveValorA.equals(a))
			){
				jaExiste = true;
				break;
			}
		}
		
		if(!jaExiste){
			naoExistem.add(new ComparacaoJson( a , b ));
		}
	}
}
