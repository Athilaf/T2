package br.com.athila.model;

import java.util.ArrayList;
import java.util.List;

public class ResultadoComparacaoArquivos{

	public Integer numeroVersaoA;
	public Integer numeroVersaoB;
	public List<String> servidoresA = new ArrayList<String>(0);
	public List<String> servidoresB = new ArrayList<String>(0);
	
	public List<ComparacaoArquivos> iguais = new ArrayList<ComparacaoArquivos>(0);
	public List<ComparacaoArquivos> diferentes = new ArrayList<ComparacaoArquivos>(0);
	public List<ComparacaoArquivos> naoExistem = new ArrayList<ComparacaoArquivos>(0);
	
	public Integer getNumeroVersaoA() {
		return numeroVersaoA;
	}

	public void setNumeroVersaoA(Integer numeroVersaoA) {
		this.numeroVersaoA = numeroVersaoA;
	}

	public Integer getNumeroVersaoB() {
		return numeroVersaoB;
	}

	public void setNumeroVersaoB(Integer numeroVersaoB) {
		this.numeroVersaoB = numeroVersaoB;
	}

	public List<String> getServidoresA() {
		return servidoresA;
	}

	public void setServidoresA(List<String> servidoresA) {
		this.servidoresA = servidoresA;
	}

	public List<String> getServidoresB() {
		return servidoresB;
	}

	public void setServidoresB(List<String> servidoresB) {
		this.servidoresB = servidoresB;
	}

	public List<ComparacaoArquivos> getIguais() {
		return iguais;
	}

	public void setIguais(List<ComparacaoArquivos> iguais) {
		this.iguais = iguais;
	}

	public List<ComparacaoArquivos> getDiferentes() {
		return diferentes;
	}

	public void setDiferentes(List<ComparacaoArquivos> diferentes) {
		this.diferentes = diferentes;
	}

	public List<ComparacaoArquivos> getNaoExistem() {
		return naoExistem;
	}

	public void setNaoExistem(List<ComparacaoArquivos> naoExistem) {
		this.naoExistem = naoExistem;
	}
	
	public void addIguais(Arquivo a, Arquivo b){
		Boolean jaExiste = false;
		for(ComparacaoArquivos arqs : iguais){
			if(arqs.arquivoA.equals(a) && arqs.arquivoB.equals(b)){
				jaExiste = true;
				break;
			}
		}
		
		if(!jaExiste){
			iguais.add(new ComparacaoArquivos( a , b ));
		}
	}
	
	public void addDiferentes(Arquivo a, Arquivo b){
		Boolean jaExiste = false;
		for(ComparacaoArquivos arqs : diferentes){
			if(arqs.arquivoA.equals(a) && arqs.arquivoB.equals(b)){
				jaExiste = true;
				break;
			}
		}
		
		if(!jaExiste){
			diferentes.add(new ComparacaoArquivos( a , b ));
		}
	}
	
	public void addNaoExistem(Arquivo a, Arquivo b){
		Boolean jaExiste = false;
		for(ComparacaoArquivos arqs : naoExistem){
			
			if(
				(a == null && arqs.arquivoA == null && arqs.arquivoB != null && b != null && arqs.arquivoB.equals(b)) || 
				(b == null && arqs.arquivoB == null && arqs.arquivoA != null && a != null && arqs.arquivoA.equals(a))
			){
				jaExiste = true;
				break;
			}
		}
		
		if(!jaExiste){
			naoExistem.add(new ComparacaoArquivos( a , b ));
		}
	}
}
