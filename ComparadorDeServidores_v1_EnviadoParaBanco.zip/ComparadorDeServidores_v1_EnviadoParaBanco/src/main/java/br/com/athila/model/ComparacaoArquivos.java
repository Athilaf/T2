package br.com.athila.model;

public class ComparacaoArquivos {

	Arquivo arquivoA;
	Arquivo arquivoB;
	public Arquivo getArquivoA() {
		return arquivoA;
	}
	public void setArquivoA(Arquivo arquivoA) {
		this.arquivoA = arquivoA;
	}
	public Arquivo getArquivoB() {
		return arquivoB;
	}
	public void setArquivoB(Arquivo arquivoB) {
		this.arquivoB = arquivoB;
	}

	public ComparacaoArquivos(Arquivo a, Arquivo b){
		this.arquivoA = a;
		this.arquivoB = b;
	}
}
