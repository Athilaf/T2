package br.com.athila.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;

public class AthilaSSH {
	
	/* As configurações da sessão são feitas no objeto jSch */
	 private JSch jSch = new JSch();
	 private Session session;
	 private int port;
	 private String hostIp;
	 private String username;
	 private String password;
	 public int timeout = 3000;
	 
	 public AthilaSSH(String hostIp, int port, String user, String password){
		this.hostIp = hostIp;
		this.port = port;
		this.username =  user;
		this.password = password;
		 
		try {
			session = jSch.getSession(this.username, this.hostIp, this.port);
			session.setPassword(this.password);
			 
			Properties config = new Properties();
			config.put("StrictHostKeyChecking", "no");
			session.setConfig(config);
			session.connect(timeout);
			System.out.println("OK SERVIDOR ["+hostIp+"] Session conectado.");
		} catch (JSchException e) {
			System.out.println("ERRO SERVIDOR ["+hostIp+"] Session conectado JSchException : "+e.getMessage());
			e.printStackTrace();
		}
	 }
	
	 public void Disconect(){
		 if(session != null){
			try{
				session.disconnect();
				System.out.println("OK SERVIDOR ["+hostIp+"] Session fechada.");
			} catch (Exception e) {
				System.out.println("ERRO SERVIDOR ["+hostIp+"] Session fechada Exception : "+e.getMessage());
				e.printStackTrace();
			}
		 }
	 }
	 
	 public List<String> ExecutaComando(String command) {
	 
		List<String> retorno = new ArrayList<String>(0);
		try {
			Channel channel=session.openChannel("exec");
			
			System.out.println("OK SERVIDOR ["+hostIp+"] Canal aberto.");
			
			((ChannelExec)channel).setCommand(command);
			((ChannelExec)channel).setErrStream(System.err);
	
			InputStream in=channel.getInputStream();
	
			channel.connect();
			System.out.println("OK SERVIDOR ["+hostIp+"] Canal conectado.");
	
			byte[] tmp=new byte[1024];
			while(true){
				while(in.available()>0){
					int i=in.read(tmp, 0, 1024);
					if(i<0)break;
					//System.out.print(new String(tmp, 0, i));
					retorno.add(new String(tmp, 0, i));
				}
				if(channel.isClosed()){
					System.out.println("OK SERVIDOR ["+hostIp+"] Canal Fechado.");
					break;
				}
			}

			channel.disconnect();
			
		} catch (IOException e) {
			System.out.println("ERRO SERVIDOR ["+hostIp+"] Canal IOException : "+e.getMessage());
			e.printStackTrace();
		} catch (JSchException e) {
			System.out.println("ERRO SERVIDOR ["+hostIp+"] Canal JSchException : "+e.getMessage());
			e.printStackTrace();
		}

		
		List<String> retornoFim = new ArrayList<String>(0);
		
		for(String s: retorno){
			String[] linhas = s.split("\n");
			for(String linha: linhas){
				if(linha != null && !linha.isEmpty()){
					retornoFim.add(linha);
				}
			}
		}
		
		for(String s: retornoFim){
			if(s == null){
				//System.out.println(s);
				retornoFim.remove(s);
			}else{
				//System.out.println(s);
			}
				
		}
		
		return retornoFim;
	}
	 
	 public List<String> getArquivos(String caminho){
		 String cmd = "cd ~ ; cd \"" + caminho + "\" ; ls -l ;";
		 return ExecutaComando(cmd);
	 }

}
