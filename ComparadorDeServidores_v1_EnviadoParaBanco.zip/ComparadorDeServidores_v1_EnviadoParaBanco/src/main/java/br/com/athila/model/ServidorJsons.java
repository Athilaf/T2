package br.com.athila.model;

import java.util.ArrayList;
import java.util.List;

public class ServidorJsons {
	
	public String nomeServidor;
	public List<ChaveValor> listaJsons = new ArrayList<ChaveValor>(0);
	
	public ServidorJsons(String nomeServidor, List<ChaveValor> listaJsons){
		this.nomeServidor = nomeServidor;
		this.listaJsons = listaJsons;
	}
	
	public Boolean equals(List<ChaveValor> listaB){
		Boolean retorno = true;
		
		if(listaJsons.size() == listaB.size()){ 
			for (ChaveValor a : listaJsons) {
				
				retorno = false;
				
				for (ChaveValor b : listaB) {
					if(a.equals(b)){
						retorno = true;
						break;
					}
				}
				
				if(!retorno){
					break;
				}
		    }
		}else{
			return false;
		}
		
		return retorno;
	}
	
	public Boolean contem(ChaveValor cv){
		Boolean retorno = false;
		
		for (ChaveValor a : listaJsons) {
			
			if(a.chave.equals(cv.chave)){
				retorno = true;
				break;
			}
	    }
		
		return retorno;
	}
	
	public Boolean contem(List<ChaveValor> cvs){
		Boolean retorno = false;
		
		for (ChaveValor a : cvs) {
			
			if(contem(a)){
				retorno = true;
				break;
			}
	    }
		
		return retorno;
	}
	
	public Boolean contemIgual(ChaveValor cv){
		Boolean retorno = false;
		
		for (ChaveValor a : listaJsons) {
			
			if(a.equals(cv)){
				retorno = true;
				break;
			}
	    }
		
		return retorno;
	}
	
	public Boolean contemIgual(List<ChaveValor> cvs){
		Boolean retorno = false;
		
		for (ChaveValor a : cvs) {
			
			if(contemIgual(a)){
				retorno = true;
				break;
			}
	    }
		
		return retorno;
	}
	
	public ChaveValor getChaveValor(String chave){
	
		for (ChaveValor a : listaJsons) {
			
			if(a.chave.toLowerCase().equals(chave.toLowerCase())){
				return a;
			}
	    }
		
		return null;
	}
}
