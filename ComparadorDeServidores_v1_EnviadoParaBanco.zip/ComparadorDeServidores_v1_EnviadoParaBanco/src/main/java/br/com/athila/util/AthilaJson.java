package br.com.athila.util;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.util.DefaultPrettyPrinter;
import com.fasterxml.jackson.core.util.DefaultPrettyPrinter.Lf2SpacesIndenter;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.google.common.collect.Lists;

import br.com.athila.model.ChaveValor;

public class AthilaJson {

	public static ObjectNode JsonExemplo1_Obj(){


		ObjectMapper mapper = new ObjectMapper();
		 
        ArrayNode arrayNode = mapper.createArrayNode();
 
        ObjectNode root = mapper.createObjectNode();
        
        root.put("A0", "0");
        ObjectNode o1 = mapper.createObjectNode();
        o1.put("O1", "11");
        o1.put("O2", "12");
        root.put("A1", o1);
        
        root.put("A6", "6");
        
        ObjectNode objectNode1 = mapper.createObjectNode();
        objectNode1.put("n1P1", "n1P1");
        objectNode1.put("n1P2", "n1P2");
 
        ObjectNode objectNode2 = mapper.createObjectNode();
        objectNode2.put("n2P1", "n2P1");
        objectNode2.put("n2P2", "n2P2");
 
        ObjectNode objectNode3 = mapper.createObjectNode();
        objectNode3.put("n3P1", "n3P1");
        objectNode3.put("n3P2", "n3P2");
 
        arrayNode.add(objectNode2);
        arrayNode.add(objectNode3);
        arrayNode.add(objectNode1);
  
        root.put("A2", arrayNode);
        
        root.put("A3", "3");
        root.put("A4", "4");
        
        return root;
	}
	
	public static String JsonExemplo1(){
		try {
			ObjectMapper mapper = new ObjectMapper();
			return mapper.writerWithDefaultPrettyPrinter().writeValueAsString(JsonExemplo1_Obj());
		} catch (JsonProcessingException e) {
			return null;
		}
	}
	
	public static ObjectNode JsonExemplo2_Obj(){


		ObjectMapper mapper = new ObjectMapper();
		 
        ArrayNode arrayNode = mapper.createArrayNode();
 
        ObjectNode root = mapper.createObjectNode();
        
        root.put("A0", "0");
        
        root.put("A4", "4");
        
        
        ObjectNode objectNode1 = mapper.createObjectNode();
        objectNode1.put("n1P1", "n1P11");
        objectNode1.put("n1P2", "n1P2");
 
        ObjectNode objectNode2 = mapper.createObjectNode();
        objectNode2.put("n2P1", "n2P1");
        objectNode2.put("n2P2", "n2P2");
 
        ObjectNode objectNode3 = mapper.createObjectNode();
        objectNode3.put("n3P1", "n33P1");
        objectNode3.put("n3P2", "n3P2");
 
        arrayNode.add(objectNode2);
        arrayNode.add(objectNode3);
        arrayNode.add(objectNode1);
  
        root.put("A2", arrayNode);
        
        root.put("A3", "33");
        
        root.put("A5", "5");
        
        ObjectNode o1 = mapper.createObjectNode();
        o1.put("O1", "11");
        o1.put("O2", "122");
        root.put("A1", o1);
        
        return root;
	}
	
	public static String JsonExemplo2(){
		try {
			ObjectMapper mapper = new ObjectMapper();
			return mapper.writerWithDefaultPrettyPrinter().writeValueAsString(JsonExemplo2_Obj());
		} catch (JsonProcessingException e) {
			return null;
		}
	}
	
//	public static ResultadoComparacaoJson DiffComparacao(JsonNode a, JsonNode b){
//		
//		return DiffComparacao( listaItens(a), listaItens(b));
//	}
//	
//	public static ResultadoComparacaoJson DiffComparacao(List<ChaveValor> a,List<ChaveValor> b){
//	
//		ResultadoComparacaoJson resultadoComparacaoJson = new ResultadoComparacaoJson();
//		
//		for(ChaveValor cva : a){
//			ChaveValor cvbTMP = ExistInList(b, cva);
//			if(cvbTMP != null){
//				if(cvbTMP.equals(cva)){
//					//Igual
//					resultadoComparacaoJson.addIguais(cva, cvbTMP);
//				}else{
//					//Diferente
//					resultadoComparacaoJson.addDiferentes(cva, cvbTMP);
//				}
//			}else{
//				//Não existe
//				resultadoComparacaoJson.addNaoExistem(cva, null);
//			}
//		}
//		
//		for(ChaveValor cvb : b){
//			ChaveValor cvaTMP = ExistInList(a, cvb);
//			if(cvaTMP == null){
//				//Não existe
//				resultadoComparacaoJson.addNaoExistem(null, cvb);
//			}
//		}
//		
//		return resultadoComparacaoJson;
//	}
//	
//	public static ChaveValor ExistInList(List<ChaveValor> a, ChaveValor chaveValor){
//		
//		for(ChaveValor cva : a){
//			if(cva.chave.equals(chaveValor.chave)){
//				return cva;
//			}
//		}
//		
//		return null;
//	}
//	
//	private static String Diff(JsonNode a, JsonNode b){
//		String diff = "";
//		try {
//			ObjectMapper jackson = new ObjectMapper(); 
//			JsonNode beforeNode;
//		
//			beforeNode = jackson.readTree(JsonExemplo1());
//		 
//			JsonNode afterNode = jackson.readTree(JsonExemplo2()); 
//			JsonNode patchNode = JsonDiff.asJson(beforeNode, afterNode); 
//			diff = patchNode.toString();
//		} catch (Exception e) {
//			diff = "Erro Exception";
//		}
//		return diff;
//	}
	
	public String ConvertToString(JsonNode jsonNode){
		
		String saida = "";
	
		try 
		{
			ObjectMapper mapper = new ObjectMapper();
			String jsonInString = mapper.writeValueAsString(jsonNode);
			
			saida = jsonInString;
		} catch (IOException e) {
			saida = "[\"Erro - " + e.getMessage() + "\"]";
		}
		
		return saida;
	}
	
	public static String ConvertObjectToJsonString(Object o){
		
		String saida = "";
	
		try 
		{
			ObjectMapper mapper = new ObjectMapper();
			String jsonInString = mapper.writeValueAsString(o);
			
			saida = jsonInString;
		} catch (IOException e) {
			saida = "[\"" + e.getMessage() + "\"]";
			e.printStackTrace();
		}
		
		return saida;
	}
	
	public static JsonNode ConvertToJsonNode(String stringJson){
		ObjectMapper mapper = new ObjectMapper();
		JsonNode obj;
		try {
			obj = mapper.readTree(stringJson);
		} catch (Exception e) {
			return null;
		}
		
		return obj;
	}
	
//	private static final ObjectMapper SORTED_MAPPER = new ObjectMapper();
//	static {
//	    SORTED_MAPPER.configure(SerializationFeature.ORDER_MAP_ENTRIES_BY_KEYS, true);
//	}
//
//	public static String ordena(final JsonNode node) throws JsonProcessingException {
//	    final Object obj = SORTED_MAPPER.treeToValue(node, Object.class);
//	    final String json = SORTED_MAPPER.writeValueAsString(obj);
//	    return json;
//	}
//	
//	public static JsonNode ordenaJsonNode(final JsonNode node) throws JsonProcessingException {
//	    final Object obj = SORTED_MAPPER.treeToValue(node, Object.class);
//	    
//	    final String json = SORTED_MAPPER.writeValueAsString(obj);
//	    
//	    return ConvertStringToJsonNode(json);
//	}
	
	public static String listaItensString(JsonNode no){
		
		String saida = "";
		
		List<ChaveValor> listaChaveValor = listaItens(no);
		
		for(ChaveValor cv : listaChaveValor){
			saida += cv.chave + ":" + cv.valor + "\n";
		}
		
		return saida;
	}
	
	public static List<ChaveValor> listaItens(String strNo){
		JsonNode no = ConvertToJsonNode(strNo);
		return listaItens(no);
	}
	
	public static List<ChaveValor> listaItens(JsonNode no){
	
		List<ChaveValor> listaChaveValor = new ArrayList<ChaveValor>();
		
		return listaItens("", no, listaChaveValor);
	}
	
	private static List<ChaveValor> listaItens(String pai, JsonNode no, List<ChaveValor> listaChaveValor){
	
		if (no.isArray()) {
		    for (final JsonNode objNode : no) {
	        
		    	listaItens(pai + "/[]", objNode, listaChaveValor);
		    }
		}else{
		
			Iterator<Entry<String, JsonNode>> nodes = no.fields();
	
			while (nodes.hasNext()) {
			  Map.Entry<String, JsonNode> entry = (Map.Entry<String, JsonNode>) nodes.next();
	
			  if(entry.getValue() instanceof ObjectNode){
				  listaItens(pai + "/" + entry.getKey(), entry.getValue(), listaChaveValor);
			  }else if(entry.getValue() instanceof ArrayNode){
				  listaItens(pai + "/" + entry.getKey(), entry.getValue(), listaChaveValor);
			  }else{
				  String resultado = entry.getValue().toString();
				  
				  if(resultado == null){
					  System.out.println(entry.getValue().toString());
				  }
				  
				  ChaveValor chaveValor = new ChaveValor(pai + "/" + entry.getKey(), resultado);
				  listaChaveValor.add(chaveValor);
			  }
			}
		}
		
		return listaChaveValor;
	}
	
//	public static String ordena(String s) {
//		String json = "";
//		try{
//			json = SORTED_MAPPER.writeValueAsString(s);
//		}catch (Exception e) {
//			json = "Erro";
//		}
//	    return json;
//	}
	
	public static class Ordenacao {

		public static String sort(String in) throws IOException, JsonParseException, JsonProcessingException {
			JsonFactory factory = new JsonFactory();
			factory.configure(JsonParser.Feature.AUTO_CLOSE_SOURCE, false);
			factory.configure(JsonParser.Feature.ALLOW_SINGLE_QUOTES, true);
			JsonParser jp = factory.createParser(in);

			ObjectMapper mapper = new ObjectMapper();

			JsonNode tree = mapper.readTree(jp);
			
			return sortObj(tree);
		}
		
		public static String sortObj(JsonNode no) throws IOException, JsonParseException, JsonProcessingException {
			ObjectMapper mapper = new ObjectMapper();

			JsonNode tree = no;
			sort(tree);

			DefaultPrettyPrinter pp = new DefaultPrettyPrinter();
			pp.indentArraysWith(new Lf2SpacesIndenter());
			String result = mapper.writer(pp).writeValueAsString(tree);
			return result;
		}

		protected static void sort(JsonNode tree) {

			if (tree.isObject()) {
				sortObject(tree);
			} else if (tree.isArray()) {
				sortArray(tree);
			}
		}

		protected static void sortArray(JsonNode tree) {

			for (JsonNode jsonNode : tree) {
				sort(jsonNode);
			}

			List<JsonNode> list = Lists.newArrayList(((ArrayNode) tree).iterator());
			Collections.sort(list, new JsonNodeComparator());
			((ArrayNode) tree).removeAll();
			((ArrayNode) tree).addAll(list);
		}

		protected static void sortObject(JsonNode tree) {
			List<String> asList = Lists.newArrayList(tree.fieldNames());
			Collections.sort(asList);
			LinkedHashMap<String, JsonNode> map = new LinkedHashMap<String, JsonNode>();
			for (String f : asList) {

				JsonNode value = tree.get(f);
				sort(value);
				map.put(f, value);
			}
			((ObjectNode) tree).removeAll();
			((ObjectNode) tree).setAll(map);
		}

		protected static class JsonNodeComparator implements Comparator<JsonNode> {
			public int compare(JsonNode o1, JsonNode o2) {
				if (o1 == null && o2 == null) {
					return 0;
				}

				if (o1 == null) {
					return -1;
				}
				if (o2 == null) {
					return 1;
				}

				if (o1.isObject() && o2.isObject()) {
					return compObject(o1, o2);
				} else if (o1.isArray() && o2.isArray()) {
					return compArray(o1, o2);
				} else if (o1.isValueNode() && o2.isValueNode()) {
					return compValue(o1, o2);
				} else {
					return 1;
				}
			}

			protected int compValue(JsonNode o1, JsonNode o2) {

				if (o1.isNull()) {
					return -1;
				}

				if (o2.isNull()) {
					return 1;
				}

				if (o1.isNumber() && o2.isNumber()) {
					return o1.bigIntegerValue().compareTo(o2.bigIntegerValue());
				}

				return o1.asText().compareTo(o2.asText());
			}

			protected int compArray(JsonNode o1, JsonNode o2) {

				int c = ((ArrayNode) o1).size() - ((ArrayNode) o2).size();
				if (c != 0) {
					return c;
				}
				for (int i = 0; i < ((ArrayNode) o1).size(); i++) {
					c = compare(o1.get(i), o2.get(i));
					if (c != 0) {
						return c;
					}
				}

				return 0;
			}

			protected int compObject(JsonNode o1, JsonNode o2) {

				String id1 = o1.get("id") == null ? null : o1.get("id").asText();
				String id2 = o2.get("id") == null ? null : o2.get("id").asText();
				if (id1 != null) {
					int c = id1.compareTo(id2);
					if (c != 0) {
						return c;
					}
				}
				int c = ((ObjectNode) o1).size() - ((ObjectNode) o2).size();
				if (c != 0) {
					return c;
				}

				Iterator<String> fieldNames1 = ((ObjectNode) o1).fieldNames();
				Iterator<String> fieldNames2 = ((ObjectNode) o2).fieldNames();
				for (; fieldNames1.hasNext();) {
					String f = fieldNames1.next();

					c = f.compareTo(fieldNames2.next());
					if (c != 0) {
						return c;
					}

					JsonNode n1 = o1.get(f);
					JsonNode n2 = o2.get(f);
					c = compare(n1, n2);
					if (c != 0) {
						return c;
					}
				}
				return 0;
			}
		}
	}
}
