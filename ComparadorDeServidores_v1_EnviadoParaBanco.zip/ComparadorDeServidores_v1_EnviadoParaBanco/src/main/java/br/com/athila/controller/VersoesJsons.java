package br.com.athila.controller;

import java.util.ArrayList;
import java.util.List;

import br.com.athila.model.ChaveValor;
import br.com.athila.model.ResultadoComparacaoJson;
import br.com.athila.model.ServidorJsons;

public class VersoesJsons {

public List<List<ServidorJsons>> listaVersoes = new ArrayList<List<ServidorJsons>>(0);
	
	public List<List<ServidorJsons>> getListaVersoes() {
		return listaVersoes;
	}

	public void setListaVersoes(List<List<ServidorJsons>> listaVersoes) {
		this.listaVersoes = listaVersoes;
	}

//	public void addForStrings(String nomeServidor, List<String> listaStringArquivos){
//		List<Arquivo> lista = new ArrayList<Arquivo>(0);
//		
//		for(String s : listaStringArquivos) {  
//			 Arquivo a = Arquivo.convertToArquivo(s);
//			 if(a != null){
//				 lista.add(a);
//			 }
//		 }
//		
//		add(nomeServidor, lista);
//	}
	
	public void add(String nomeServidor, List<ChaveValor> listaChaveValor){
		
		ServidorJsons servidorJsons = new ServidorJsons(nomeServidor, listaChaveValor);
		Boolean encontrou = false;
		
		if(listaVersoes.size() > 0){
			
			for(List<ServidorJsons> itemListaVersoes : listaVersoes){
				
				if(itemListaVersoes.get(0).equals(listaChaveValor)){
					
					itemListaVersoes.add(servidorJsons);
					encontrou = true;
				}
			}
		}

		if(!encontrou){
			List<ServidorJsons> listaServidores = new ArrayList<ServidorJsons>(0);
			listaServidores.add(servidorJsons);
			listaVersoes.add(listaServidores);
		}
	}
	
	public List<ResultadoComparacaoJson> Comparar(){
		
		List<ResultadoComparacaoJson> listaResultados = new ArrayList<ResultadoComparacaoJson>(0);
		
		if(listaVersoes.size() > 1){
			
			for(int i = 0 ; listaVersoes.size() > i; i++){
				for(int j = i ; listaVersoes.size() > j; j++){
		
					if(i != j){
						
						ResultadoComparacaoJson resultadoComparacao = Comparar(i, j);
						
						if(resultadoComparacao != null){
							listaResultados.add(resultadoComparacao);
						}
					}
				}
			}
		
		}else{
			if(listaVersoes.size() > 0){
				ResultadoComparacaoJson resultadoComparacao = new ResultadoComparacaoJson();
				resultadoComparacao.numeroVersaoA = 0;
				
				for(int x = 0; listaVersoes.get(0).size() > x; x++){
					resultadoComparacao.servidoresA.add(listaVersoes.get(0).get(x).nomeServidor);
				}
				
				for(List<ServidorJsons> servidorJsons : listaVersoes){
					for(ChaveValor arq : servidorJsons.get(0).listaJsons){
						resultadoComparacao.addIguais(arq, null);
					}
				}
				
				listaResultados.add(resultadoComparacao);
			}
		}
		
		return listaResultados;
	}
	
	public ResultadoComparacaoJson Comparar(int i, int j){
		
		ResultadoComparacaoJson resultadoComparacao = new ResultadoComparacaoJson();
		
		resultadoComparacao.numeroVersaoA = i;
		resultadoComparacao.numeroVersaoB = j;
		
		ServidorJsons vA = listaVersoes.get(i).get(0);
		ServidorJsons vB = listaVersoes.get(j).get(0);
		
		for(int x = 0; listaVersoes.get(i).size() > x; x++){
			resultadoComparacao.servidoresA.add(listaVersoes.get(i).get(x).nomeServidor);
		}
		
		for(int x = 0; listaVersoes.get(j).size() > x; x++){
			resultadoComparacao.servidoresB.add(listaVersoes.get(j).get(x).nomeServidor);
		}
		
		if(vA != null && vB != null){
		
			for(int z = 0 ; vA.listaJsons.size() > z ; z++){
				
				ChaveValor arqB = vB.getChaveValor(vA.listaJsons.get(z).chave);
				
				if(arqB != null){

					if(vA.listaJsons.get(z).equals(arqB)){
						// Existe igual
						resultadoComparacao.addIguais(vA.listaJsons.get(z), arqB);
					}else{
						// Existe diferente
						resultadoComparacao.addDiferentes(vA.listaJsons.get(z), arqB);
					}
				}else{
					// Nao existe B em A
					resultadoComparacao.addNaoExistem(vA.listaJsons.get(z), null);
					//break;
				}
			}
			
			for(int z = 0 ; vB.listaJsons.size() > z ; z++){
				
				if(vA.getChaveValor(vB.listaJsons.get(z).chave) == null){
			
					// Nao existe A em B
					resultadoComparacao.addNaoExistem(null, vB.listaJsons.get(z));
				}
			}
			
			return resultadoComparacao;
		}
		
		return null;
	}
	
}
