package br.com.athila.model;

public class ComparacaoJson {

	ChaveValor chaveValorA;
	ChaveValor chaveValorB;
	public ChaveValor getArquivoA() {
		return chaveValorA;
	}
	public void setArquivoA(ChaveValor chaveValorA) {
		this.chaveValorA = chaveValorA;
	}
	public ChaveValor getArquivoB() {
		return chaveValorB;
	}
	public void setArquivoB(ChaveValor chaveValorB) {
		this.chaveValorB = chaveValorB;
	}

	public ComparacaoJson(ChaveValor a, ChaveValor b){
		this.chaveValorA = a;
		this.chaveValorB = b;
	}
}