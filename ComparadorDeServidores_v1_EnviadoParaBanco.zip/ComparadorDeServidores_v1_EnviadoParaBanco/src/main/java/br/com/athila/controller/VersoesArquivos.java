package br.com.athila.controller;

import java.util.ArrayList;
import java.util.List;

import br.com.athila.model.Arquivo;
import br.com.athila.model.ResultadoComparacaoArquivos;
import br.com.athila.model.ServidorArquivos;

public class VersoesArquivos {

	public List<List<ServidorArquivos>> listaVersoes = new ArrayList<List<ServidorArquivos>>(0);
	
	public List<List<ServidorArquivos>> getListaVersoes() {
		return listaVersoes;
	}

	public void setListaVersoes(List<List<ServidorArquivos>> listaVersoes) {
		this.listaVersoes = listaVersoes;
	}

	public void addForStrings(String nomeServidor, List<String> listaStringArquivos){
		List<Arquivo> lista = new ArrayList<Arquivo>(0);
		
		for(String s : listaStringArquivos) {  
			 Arquivo a = Arquivo.convertToArquivo(s);
			 if(a != null){
				 lista.add(a);
			 }
		 }
		
		add(nomeServidor, lista);
	}
	
	public void add(String nomeServidor, List<Arquivo> listaArquivos){
		
		ServidorArquivos servidorArquivos = new ServidorArquivos(nomeServidor, listaArquivos);
		Boolean encontrou = false;
		
		if(listaVersoes.size() > 0){
			
			for(List<ServidorArquivos> itemListaVersoes : listaVersoes){
				
				if(itemListaVersoes.get(0).equals(listaArquivos)){
					
					itemListaVersoes.add(servidorArquivos);
					encontrou = true;
				}
			}
		}

		if(!encontrou){
			List<ServidorArquivos> listaServidores = new ArrayList<ServidorArquivos>(0);
			listaServidores.add(servidorArquivos);
			listaVersoes.add(listaServidores);
		}
	}
	
	public List<ResultadoComparacaoArquivos> Comparar(){
		
		List<ResultadoComparacaoArquivos> listaResultados = new ArrayList<ResultadoComparacaoArquivos>(0);
		
		if(listaVersoes.size() > 1){
			
			for(int i = 0 ; listaVersoes.size() > i; i++){
				for(int j = i ; listaVersoes.size() > j; j++){
		
					if(i != j){
						
						ResultadoComparacaoArquivos resultadoComparacao = Comparar(i, j);
						
						if(resultadoComparacao != null){
							listaResultados.add(resultadoComparacao);
						}
					}
				}
			}
		
		}else{
			if(listaVersoes.size() > 0){
				ResultadoComparacaoArquivos resultadoComparacao = new ResultadoComparacaoArquivos();
				resultadoComparacao.numeroVersaoA = 0;
				
				for(int x = 0; listaVersoes.get(0).size() > x; x++){
					resultadoComparacao.servidoresA.add(listaVersoes.get(0).get(x).nomeServidor);
				}
				
				for(List<ServidorArquivos> servidorArquivos : listaVersoes){
					for(Arquivo arq : servidorArquivos.get(0).listaArquivos){
						resultadoComparacao.addIguais(arq, null);
					}
				}
				
				listaResultados.add(resultadoComparacao);
			}
		}
		
		return listaResultados;
	}
	
	public ResultadoComparacaoArquivos Comparar(int i, int j){
		
		ResultadoComparacaoArquivos resultadoComparacao = new ResultadoComparacaoArquivos();
		
		resultadoComparacao.numeroVersaoA = i;
		resultadoComparacao.numeroVersaoB = j;
		
		ServidorArquivos vA = listaVersoes.get(i).get(0);
		ServidorArquivos vB = listaVersoes.get(j).get(0);
		
		for(int x = 0; listaVersoes.get(i).size() > x; x++){
			resultadoComparacao.servidoresA.add(listaVersoes.get(i).get(x).nomeServidor);
		}
		
		for(int x = 0; listaVersoes.get(j).size() > x; x++){
			resultadoComparacao.servidoresB.add(listaVersoes.get(j).get(x).nomeServidor);
		}
		
		if(vA != null && vB != null){
		
			for(int z = 0 ; vA.listaArquivos.size() > z ; z++){
				
				Arquivo arqB = vB.getArquivo(vA.listaArquivos.get(z).nome);
				
				if(arqB != null){

					if(vA.listaArquivos.get(z).equals(arqB)){
						// Existe igual
						resultadoComparacao.addIguais(vA.listaArquivos.get(z), arqB);
					}else{
						// Existe diferente
						resultadoComparacao.addDiferentes(vA.listaArquivos.get(z), arqB);
					}
				}else{
					// Nao existe B em A
					resultadoComparacao.addNaoExistem(vA.listaArquivos.get(z), null);
					//break;
				}
			}
			
			for(int z = 0 ; vB.listaArquivos.size() > z ; z++){
				
				if(vA.getArquivo(vB.listaArquivos.get(z).nome) == null){
			
					// Nao existe A em B
					resultadoComparacao.addNaoExistem(null, vB.listaArquivos.get(z));
				}
			}
			
			return resultadoComparacao;
		}
		
		return null;
	}
	
	public String ConvertToString(){
		String saida = "";
		
		List<ResultadoComparacaoArquivos> resultados = Comparar();
		
		if(resultados == null){
			saida += "Nao existem resultados para comparar. \n";
		}else{
			for(ResultadoComparacaoArquivos r : resultados){
				saida += "Versoes: " + r.numeroVersaoA + " X " + r.numeroVersaoB + "\n";
				
				if(r.diferentes.size() > 0){
					saida += "Arquivos Diferentes: " + r.diferentes.size() + "\n";
					for(int i = 0; r.diferentes.size() > i ; i++){
						
						saida += r.diferentes.get(i).getArquivoA().nome + " != " + r.diferentes.get(i).getArquivoB().nome + "\n";
						
					}
				}
				
				if(r.naoExistem.size() > 0){
					saida += "Arquivos Nao Existem: " + r.naoExistem.size() + "\n";
					for(int i = 0; r.naoExistem.size() > i ; i++){
						
						saida += ((r.naoExistem.get(i).getArquivoA() != null)? r.naoExistem.get(i).getArquivoA().nome : "NULL") + " ?? " + ((r.naoExistem.get(i).getArquivoB() != null)? r.naoExistem.get(i).getArquivoB().nome : "NULL") + "\n";
						
					}
				}
				
				if(r.iguais.size() > 0){
					saida += "Arquivos Iguais: " + r.iguais.size() + "\n";
					for(int i = 0; r.iguais.size() > i ; i++){
						
						saida += r.iguais.get(i).getArquivoA().nome + " == " + r.iguais.get(i).getArquivoA().nome + "\n";
						
					}
				}
			}
		}
		return saida;
	}
}
