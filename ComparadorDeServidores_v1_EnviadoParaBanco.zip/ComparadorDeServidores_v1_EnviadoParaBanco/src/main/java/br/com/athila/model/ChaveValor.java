package br.com.athila.model;

public class ChaveValor{
	public String chave;
	public String valor;
	
	public ChaveValor(String chave, String valor){
		this.chave = chave;
		this.valor = valor;
	}
	
	public Boolean equals(ChaveValor cv){
		if(this.chave.equals(cv.chave) && this.valor.equals(cv.valor)){
			return true;
		}
		
		return false;
	}
}
