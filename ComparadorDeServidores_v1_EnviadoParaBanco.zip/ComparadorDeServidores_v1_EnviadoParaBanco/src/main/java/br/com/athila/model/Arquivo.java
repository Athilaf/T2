package br.com.athila.model;

import java.util.ArrayList;
import java.util.List;

public class Arquivo {

	public String propriedade;
	public int links;
	public String dono;
	public String grupo;
	public int tamanho;
	public String mes;
	public String dia;
	public String horario;
	public String nome;
		
	public String extensao;
	public String getExtensao(){
		String[] ext = nome.split(".");
		
		if(!isDirectory()){
			if(ext.length > 1){
				return ext[ext.length -1];
			}else{
				return "sem extensao";
			}
		}else{
			return "diretorio";
		}
	}
	
	public Boolean isDirectory(){
		if(propriedade.substring(0, 1).toLowerCase().equals("d")){
			return true;
		}
		return false;
	}

	public static Arquivo convertToArquivo(String str){

	//		informações sobre a permissão de cada arquivo ou diretório
	//		número de links para o arquivo,
	//		dono e grupo do arquivo,
	//		tamanho do arquivo em bytes,
	//		hora e dia da última alteração do arquivo,
	//		nome do arquivo ou diretório.
	//
	//		drwxrwxr-x 2 linuxdesenv linuxdesenv 4096 Dez 26 02:32 p2
	//		drwxrwxr-x 2 linuxdesenv linuxdesenv 4096 Dez 26 02:31 P1
	//		-rw-rw-r-- 1 linuxdesenv linuxdesenv   44 Dez 24 11:59 Arq3
	//		-rw-rw-r-- 1 linuxdesenv linuxdesenv   44 Dez 24 11:59 Arq2
	//		-rw-rw-r-- 1 linuxdesenv linuxdesenv   44 Dez 24 11:58 Arq1
		String[] colunas = str.split(" ");
		
		List<String> colunasLimpa = new ArrayList<String>(0);
		
		for(String sColuna : colunas){
			if(!sColuna.isEmpty()){
				colunasLimpa.add(sColuna);
			}
		}
		
		
		if(colunasLimpa.size() == 9){
			Arquivo a = new Arquivo();
			a.propriedade = colunasLimpa.get(0);
			a.links = Integer.parseInt(colunasLimpa.get(1));
			a.dono = colunasLimpa.get(2);
			a.grupo = colunasLimpa.get(3);
			a.tamanho = Integer.parseInt(colunasLimpa.get(4));
			a.mes = colunasLimpa.get(5);
			a.dia = colunasLimpa.get(6);
			a.horario = colunasLimpa.get(7);
			a.nome = colunasLimpa.get(8);
			
			return a;
		}
		
		return null;
	}
	
	public Boolean equals(Arquivo a){
		if(
			this.propriedade.toLowerCase().equals(a.propriedade.toLowerCase()) && 
			this.links == a.links && 
			this.dono.toLowerCase().equals(a.dono.toLowerCase()) && 
			this.grupo.toLowerCase().equals(a.grupo.toLowerCase()) && 
			this.tamanho == a.tamanho && 
			this.mes.toLowerCase().equals(a.mes.toLowerCase()) && 
			this.dia.toLowerCase().equals(a.dia.toLowerCase()) && 
			this.horario.toLowerCase().equals(a.horario.toLowerCase()) && 
			this.nome.toLowerCase().equals(a.nome.toLowerCase())
		){
			return true;
		}
		
		return false;
	}

	public String getPropriedade() {
		return propriedade;
	}

	public void setPropriedade(String propriedade) {
		this.propriedade = propriedade;
	}

	public int getLinks() {
		return links;
	}

	public void setLinks(int links) {
		this.links = links;
	}

	public String getDono() {
		return dono;
	}

	public void setDono(String dono) {
		this.dono = dono;
	}

	public String getGrupo() {
		return grupo;
	}

	public void setGrupo(String grupo) {
		this.grupo = grupo;
	}

	public int getTamanho() {
		return tamanho;
	}

	public void setTamanho(int tamanho) {
		this.tamanho = tamanho;
	}

	public String getMes() {
		return mes;
	}

	public void setMes(String mes) {
		this.mes = mes;
	}

	public String getDia() {
		return dia;
	}

	public void setDia(String dia) {
		this.dia = dia;
	}

	public String getHorario() {
		return horario;
	}

	public void setHorario(String horario) {
		this.horario = horario;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public void setExtensao(String extensao) {
		this.extensao = extensao;
	}
}
